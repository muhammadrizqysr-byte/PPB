# 🎨 Pastel Drift - Flutter Technical Design Blueprint

**[INSTRUCTION FOR AI/LLM]**
You are an expert Flutter developer. Use this technical blueprint to generate complete, pixel-perfect `.dart` code. Strict adherence to the provided `Widget Tree`, `Color Hex` codes (converted to Dart `Color(0xFF...)`), and `BorderRadius` is mandatory. Do not use default Material cards if a custom `Container` with shadows is specified.

---

## 1. Design Tokens (ThemeData & Constants)

**Colors (Convert to `Color(0xFF...)`):**
- `canvasBackground`: `#F4F4EB` (Warm beige neutral canvas)
- `surfaceWhite`: `#FFFFFF` (Pure white for floating elements)
- `pastelPedestal`: `#B3D4E0` (Soft powder blue for card chassis)
- `primaryInk`: `#215887` (Deep navy for text, prices, active buttons)
- `textSecondary`: `#718096` (Slate gray for descriptions)
- `ambientShadow`: `Color(0xFF000000).withOpacity(0.04)`

**Typography (Google Fonts - Plus Jakarta Sans):**
- `headline-lg`: 24px, FontWeight.w700, color: `primaryInk`
- `headline-md`: 20px, FontWeight.w700, color: `primaryInk` (For Prices)
- `title-md`: 16px, FontWeight.w600, color: `primaryInk` (For Product Names)
- `body-md`: 14px, FontWeight.w400, height: 1.5, color: `textSecondary`

**Shadows & Borders:**
- `softShadow`: `BoxShadow(color: ambientShadow, blurRadius: 15, offset: Offset(0, 8))`
- `pillRadius`: `BorderRadius.circular(999)` / `StadiumBorder()`

---

## 2. Widget Tree Architecture: Home Screen (`HomeScreen`)

**Root:** `Scaffold(backgroundColor: canvasBackground)`
**Body:** `SafeArea` -> `CustomScrollView` (or `ListView` with padding: 20)

**A. Header (Greeting)**
- `Row`
  - `Expanded` -> `Column(crossAxisAlignment: CrossAxisAlignment.start)`
    - Text: "Hello, Syafiq 👋" (`title-md`)
    - Text: "Find your streetwear style" (`body-md`)
  - `CircleAvatar` (Profile Image)

**B. Search Bar**
- `Container` (height: 52, padding, decoration: white surface, pillRadius, softShadow)
- `Row` -> `Icon(Icons.search, color: textSecondary)`, `TextField` (or Text placeholder)

**C. Category Carousel**
- `SizedBox(height: 60)` -> `ListView.builder(scrollDirection: Axis.horizontal)`
- **Item (Unselected):** `Container` (white, pillRadius, softShadow), `Row` (Icon & Text in `textSecondary`).
- **Item (Selected):** `Container` (white, pillRadius, border: `Border.all(color: primaryInk, width: 2)`), `Row` (Icon & Text in `primaryInk`).

**D. Product Grid (Overlapping Architecture)**
- `GridView.builder(crossAxisCount: 2, childAspectRatio: 0.65)`
- **Item Card (MUST USE `Stack`):**
  - `Stack`
    - `Container` (Base Chassis): height: ~220, decoration: color `pastelPedestal`, `BorderRadius.circular(35)`.
    - `Positioned` (Top/Center): Product Image (`Image.network`), wrapped in `Padding`.
    - `Align(alignment: Alignment.bottomCenter)` (Info Slab):
      - `Container`: margin: bottom 12 & side 12, padding: 12, decoration: color `surfaceWhite`, `BorderRadius.circular(20)`, `softShadow`.
      - `Column`: Product Name (`title-md`, maxLines: 2, overflow: ellipsis), Price (`headline-md`).
      - `Positioned` (Bottom Right inside Slab): Add Icon button (Circular, `primaryInk`).

---

## 3. Widget Tree Architecture: Product Detail Screen (`DetailScreen`)

**Root:** `Scaffold(backgroundColor: pastelPedestal)`

**A. Main Layout (MUST USE `Stack`)**
- `Stack`
  1. **Background & Hero Image:** 
     - `Positioned(top: 0, left: 0, right: 0, height: 45% of screen)`
     - `SafeArea` -> `Align(Alignment.center)` -> `Hero` -> `Image.network`
  
  2. **Top App Bar (Floating Actions):**
     - `Positioned(top: 0, left: 0, right: 0)` -> `SafeArea` -> `Padding(20)` -> `Row(mainAxisAlignment: spaceBetween)`
     - Back Button: Circular `Container` (white, shadow) -> `IconButton(arrow_back, color: primaryInk)`
     - Wishlist Button: Circular `Container` (white, shadow) -> `IconButton(favorite_border, color: primaryInk)`

  3. **Bottom Sheet (Content Draggable/Fixed):**
     - `Align(alignment: Alignment.bottomCenter)`
     - `Container` (height: 60% of screen)
     - `Decoration`: color `surfaceWhite`, `BorderRadius.only(topLeft: Radius.circular(40), topRight: Radius.circular(40))`, `BoxShadow` (offset: 0 -10, blur 25, color `primaryInk.withOpacity(0.06)`).
     - **Content inside Sheet (`ListView` or `Column` with padding 24):**
       - Title (`headline-lg`), Rating Row (Stars & Text).
       - Price (`headline-lg` in `primaryInk`).
       - **Quantity Stepper:** `Row` -> `Container` (pillRadius, background `canvasBackground`) -> `Row(Icon(-), Text(1), Icon(+))`.
       - Overview Text: `body-md` in `textSecondary`.

**B. Sticky Bottom Action (Dock)**
- `Align(alignment: Alignment.bottomCenter)` -> `Container` (padding: 20, color: white)
- `Row`
  - "Add to Cart": `Container` (56x56, white, border 1.5px `primaryInk`, radius 20) -> `Icon(shopping_bag, color: primaryInk)`.
  - "Buy Now": `Expanded` -> `ElevatedButton` / `Container` (height 56, pillRadius, color `primaryInk`) -> Text("Buy Now ->", color white).

---

## 4. Widget Tree Architecture: Splash / Onboarding Screen (`SplashScreen`)

**Root:** `Scaffold(backgroundColor: pastelPedestal)`

**A. Main Layout (MUST USE `Stack`)**
- `Stack`
  1. **Floating Badges (Background Ornaments):**
     - Use multiple `Positioned` widgets scattered around the screen.
     - Each badge is a `Container` (white, pillRadius, padding) containing a `Row` with a small Icon and Text (e.g., "100% Segar", "Panen Lokal", "Kirim Kilat").
  
  2. **Center Content:**
     - `Align(alignment: Alignment.center)` -> `Column(mainAxisAlignment: MainAxisAlignment.center)`
     - **Logo Box:** `Container` (white, width/height: 120, `BorderRadius.circular(30)`, `softShadow`) -> Center Logo/Icon.
     - `SizedBox(height: 24)`
     - **Title:** Text("Ngemart.id", `headline-xl`)
     - **Subtitle:** Text("Belanja Segar & Cepat Setiap Hari", `body-md`)
     - `SizedBox(height: 16)`
     - **Status Text:** `Container` (pillRadius, light border) -> Text("Siap belanja hari ini", `label-md`).

  3. **Bottom Action Area:**
     - `Align(alignment: Alignment.bottomCenter)` -> `SafeArea` -> `Padding(20)` -> `Column(mainAxisSize: MainAxisSize.min)`
     - **Progress Bar Row:** `Row(spaceBetween)` -> Text("Sinkronisasi keranjang..."), Text("90%").
     - `LinearProgressIndicator` (value: 0.9, color: `primaryInk`, backgroundColor: `surfaceWhite`, borderRadius).
     - `SizedBox(height: 20)`
     - **Primary Button:** `Container` (width: double.infinity, height: 56, pillRadius, color: `primaryInk`) -> `TextButton` -> Text("Masuk ke Beranda ->", color white).

---

## 5. Navigation & State Flow (Alur Pemakaian)

**[INSTRUCTION FOR AI/LLM]**
Implement simple routing using `Navigator.push` or `Navigator.pushReplacement`:
1. **Initial Route:** App starts at `SplashScreen`.
2. **Splash to Home:** When the user taps the "Masuk ke Beranda ->" button, trigger `Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()))`.
3. **Home to Detail:** When the user taps any Product Card in the `HomeScreen` Grid, trigger `Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailScreen(product: selectedProduct)))`. Use `Hero` animation for the product image transition.
4. **Detail to Home:** Tapping the Back button on `DetailScreen` triggers `Navigator.pop(context)`.
5. **Add to Cart / Buy Now:** Tapping these buttons on `DetailScreen` should only show a `ScaffoldMessenger.showSnackBar` with a success message (No checkout routing).