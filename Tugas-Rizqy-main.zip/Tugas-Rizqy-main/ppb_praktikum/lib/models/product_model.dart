// membuat cetakan (class) untuk responss utama yang berisi daftar produk
class ProductResponse {
  final List<Product> products; //Menyimpan daftar product
  final int total; //menyimpan total  produk di server
  final int skip;
  final int limit;

  // Constructor: Fungsi yang di panggil saat objek ini pertama kali di buat
  ProductResponse({
    required this.products,
    required this.total,
    required this.skip,
    required this.limit,
  });

  // Factory Method: Fungsi kkhusus untuk mengubah data JSON (Map) menjadi objek dart
  factory ProductResponse.fromJson(Map<String, dynamic> json) {
    List list = json['products'] as List? ?? [];
    return ProductResponse(
      // Mapping perulangan setiap item JSON menjadi objek product
      products: list.map((e) => Product.fromJson(e)).toList(),
      total: json['total'] ?? list.length,
      skip: json['skip'] ?? 0,
      limit: json['limit'] ?? 30,
    );
  }
}

// membuat cetakan untuk setiap satuan produk
class Product {
  // 'final' berarti nilainya tidak bisa di ubah lagi setelah diisi
  final int id;
  final String title;
  final String description;
  final String category; // Diubah dari enum ke String agar aman
  final double price;
  final double discountPercentage;
  final double rating;
  final int stock;
  final List<String> tags;
  final String brand;
  final String sku;
  final int weight;
  final String thumbnail;
  final List<String> images;

  Product({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.price,
    this.discountPercentage = 0,
    this.rating = 0,
    this.stock = 0,
    this.tags = const [],
    this.brand = '',
    this.sku = '',
    this.weight = 0,
    this.thumbnail = '',
    this.images = const [],
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      price: (json['price'] ?? 0).toDouble(),
      discountPercentage: (json['discountPercentage'] ?? 0).toDouble(),
      rating: (json['rating'] ?? 0).toDouble(),
      stock: json['stock'] ?? 0,
      tags: (json['tags'] as List?)?.map((e) => e.toString()).toList() ?? [],
      brand: json['brand'] ?? '',
      sku: json['sku'] ?? '',
      weight: json['weight'] ?? 0,
      images:
          (json['images'] as List?)?.map((e) => e.toString()).toList() ?? [],
      thumbnail: json['thumbnail'] ?? '',
    );
  }
    Map<String, dynamic> toJson() => {
      'title': title,
      'description' : description,
      'category': category,
      'price': price,
      'brand': brand,
      'stock': stock,
      'thumbnail': thumbnail,
  };
}

