import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import 'detail_product_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Design Tokens[cite: 14]
    const Color canvasBackground = Color(0xFFF4F4EB);
    const Color surfaceWhite = Color(0xFFFFFFFF);
    const Color pastelPedestal = Color(0xFFB3D4E0);
    const Color primaryInk = Color(0xFF215887);
    const Color textSecondary = Color(0xFF718096);
    
    final ambientShadow = BoxShadow(
      color: const Color(0xFF000000).withOpacity(0.04),
      blurRadius: 15,
      offset: const Offset(0, 8),
    );

    return Scaffold(
      backgroundColor: canvasBackground,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.all(20.0),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  // A. Header Greeting[cite: 14]
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Hello, Syafiq 👋",
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: primaryInk),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "Find your streetwear style",
                              style: TextStyle(fontSize: 14, color: textSecondary, height: 1.5),
                            ),
                          ],
                        ),
                      ),
                      const CircleAvatar(
                        radius: 24,
                        backgroundImage: NetworkImage('https://i.pravatar.cc/150?img=11'), 
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // B. Search Bar[cite: 14]
                  Container(
                    height: 52,
                    decoration: BoxDecoration(
                      color: surfaceWhite,
                      borderRadius: BorderRadius.circular(999),
                      boxShadow: [ambientShadow],
                    ),
                    child: Row(
                      children: const [
                        SizedBox(width: 16),
                        Icon(Icons.search, color: textSecondary),
                        SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Search products...',
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: textSecondary),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // C. Category Carousel[cite: 14]
                  SizedBox(
                    height: 45, // Tinggi wadah carousel
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        _buildCategoryPill(true, Icons.local_fire_department, "Trending", primaryInk, surfaceWhite, ambientShadow),
                        const SizedBox(width: 12),
                        _buildCategoryPill(false, Icons.checkroom, "Apparel", primaryInk, surfaceWhite, ambientShadow),
                        const SizedBox(width: 12),
                        _buildCategoryPill(false, Icons.snowshoeing, "Sneakers", primaryInk, surfaceWhite, ambientShadow),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ]),
              ),
            ),
            
            // D. Product Grid (Membaca langsung dari data kamu)[cite: 14]
            Consumer<ProductProvider>(
              builder: (context, provider, child) {
                if (provider.loading) {
                  return const SliverToBoxAdapter(
                    child: Center(child: CircularProgressIndicator(color: primaryInk)),
                  );
                }
                
                if (provider.products.isEmpty) {
                  return const SliverToBoxAdapter(
                    child: Center(child: Text("Data produk kosong", style: TextStyle(color: textSecondary))),
                  );
                }

                return SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 0.65, // Aspek rasio grid
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final product = provider.products[index];
                        final img = product.thumbnail.isNotEmpty ? product.thumbnail : 'https://via.placeholder.com/150';
                        
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => DetailProductScreen(
                                  // Detail screen butuh id (string) dan backgroundColor
                                  id: product.id.toString(), 
                                  backgroundColor: pastelPedestal,
                                ),
                              ),
                            );
                          },
                          // Overlapping Architecture Card[cite: 14]
                          child: Stack(
                            children: [
                              // Base Chassis[cite: 14]
                              Container(
                                height: 220,
                                decoration: BoxDecoration(
                                  color: pastelPedestal,
                                  borderRadius: BorderRadius.circular(35),
                                ),
                              ),
                              // Product Image (Top/Center)[cite: 14]
                              Positioned(
                                top: 15,
                                left: 0,
                                right: 0,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 20),
                                  child: Hero(
                                    tag: 'img-${product.id}',
                                    child: Image.network(img, height: 110, fit: BoxFit.contain),
                                  ),
                                ),
                              ),
                              // Info Slab (BottomCenter)[cite: 14]
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  margin: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
                                  padding: const EdgeInsets.all(12),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: surfaceWhite,
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [ambientShadow],
                                  ),
                                  child: Stack(
                                    children: [
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            product.title,
                                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: primaryInk),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            "\$${product.price}",
                                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: primaryInk),
                                          ),
                                          const SizedBox(height: 24), // Space untuk tombol add
                                        ],
                                      ),
                                      // Add Icon Button (Bottom Right)[cite: 14]
                                      Positioned(
                                        bottom: 0,
                                        right: 0,
                                        child: Container(
                                          padding: const EdgeInsets.all(6),
                                          decoration: const BoxDecoration(
                                            color: primaryInk,
                                            shape: BoxShape.circle,
                                          ),
                                          child: const Icon(Icons.add, color: surfaceWhite, size: 18),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                      childCount: provider.products.length,
                    ),
                  ),
                );
              },
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 40)),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryPill(bool isSelected, IconData icon, String title, Color primaryInk, Color surfaceWhite, BoxShadow shadow) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: surfaceWhite,
        borderRadius: BorderRadius.circular(999),
        boxShadow: isSelected ? null : [shadow],
        border: isSelected ? Border.all(color: primaryInk, width: 2) : null,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: isSelected ? primaryInk : const Color(0xFF718096)),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 14,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              color: isSelected ? primaryInk : const Color(0xFF718096),
            ),
          ),
        ],
      ),
    );
  }
}