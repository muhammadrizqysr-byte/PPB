import 'package:flutter/material.dart';

import '../models/product_model.dart';
import '../services/api_services_product.dart';

class DetailProductScreen extends StatefulWidget {
  final String id;
  final Color backgroundColor;

  const DetailProductScreen({
    super.key,
    required this.id,
    required this.backgroundColor,
  });

  @override
  State<DetailProductScreen> createState() => _DetailProductScreenState();
}

class _DetailProductScreenState extends State<DetailProductScreen> {
  final ApiServiceProducts _api = ApiServiceProducts();
  late Future<Product> _productFuture;

  // Design Tokens[cite: 14]
  final Color surfaceWhite = const Color(0xFFFFFFFF);
  final Color primaryInk = const Color(0xFF215887);
  final Color textSecondary = const Color(0xFF718096);
  final Color canvasBackground = const Color(0xFFF4F4EB);

  @override
  void initState() {
    super.initState();
    _productFuture = _api.getProduct(int.parse(widget.id));
  }

  @override
  Widget build(BuildContext context) {
    final shadow = BoxShadow(
      color: primaryInk.withOpacity(0.06),
      blurRadius: 25,
      offset: const Offset(0, -10),
    );

    return Scaffold(
      backgroundColor:
          widget.backgroundColor, // background: pastelPedestal[cite: 14]
      body: FutureBuilder<Product>(
        future: _productFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: primaryInk));
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return const Center(child: Text("Gagal memuat produk."));
          }

          final product = snapshot.data!;
          final img = product.thumbnail.isNotEmpty
              ? product.thumbnail
              : 'https://via.placeholder.com/150';

          return Stack(
            children: [
              // 1. Background & Hero Image[cite: 14]
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: MediaQuery.of(context).size.height * 0.45,
                child: SafeArea(
                  child: Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: const EdgeInsets.all(40.0),
                      child: Hero(
                        tag: 'img-${product.id}',
                        child: Image.network(img, fit: BoxFit.contain),
                      ),
                    ),
                  ),
                ),
              ),

              // 2. Top App Bar (Floating Actions)[cite: 14]
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildFloatingIcon(
                          Icons.arrow_back,
                          () => Navigator.pop(context),
                        ),
                        _buildFloatingIcon(Icons.favorite_border, () {}),
                      ],
                    ),
                  ),
                ),
              ),

              // 3. Bottom Sheet Content[cite: 14]
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.60,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: surfaceWhite,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                    boxShadow: [shadow],
                  ),
                  child: Column(
                    children: [
                      // Handle
                      const SizedBox(height: 16),
                      Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: textSecondary.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),

                      // Content
                      Expanded(
                        child: ListView(
                          padding: const EdgeInsets.all(24.0),
                          children: [
                            Text(
                              product.title,
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w700,
                                color: primaryInk,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(
                                  Icons.star_rounded,
                                  color: Colors.amber,
                                  size: 20,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  "${product.rating} Rating",
                                  style: TextStyle(
                                    color: textSecondary,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "\$${product.price}",
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w700,
                                    color: primaryInk,
                                  ),
                                ),
                                // Quantity Stepper[cite: 14]
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 8,
                                  ),
                                  decoration: BoxDecoration(
                                    color: canvasBackground,
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.remove,
                                        size: 18,
                                        color: primaryInk,
                                      ),
                                      const SizedBox(width: 12),
                                      Text(
                                        "1",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: primaryInk,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Icon(
                                        Icons.add,
                                        size: 18,
                                        color: primaryInk,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 24),
                            Text(
                              "Description",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: primaryInk,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              product.description,
                              style: TextStyle(
                                fontSize: 14,
                                color: textSecondary,
                                height: 1.5,
                              ),
                            ),
                            const SizedBox(
                              height: 80,
                            ), // Ruang untuk dock bawah
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // B. Sticky Bottom Action (Dock)[cite: 14]
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  padding: const EdgeInsets.all(20),
                  color: surfaceWhite,
                  child: SafeArea(
                    top: false,
                    child: Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: surfaceWhite,
                            border: Border.all(color: primaryInk, width: 1.5),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: IconButton(
                            icon: Icon(
                              Icons.shopping_bag_outlined,
                              color: primaryInk,
                            ),
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text("Added to cart")),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: SizedBox(
                            height: 56,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryInk,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                elevation: 0,
                              ),
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text("Processing purchase..."),
                                  ),
                                );
                              },
                              child: Text(
                                "Buy Now ->",
                                style: TextStyle(
                                  color: surfaceWhite,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildFloatingIcon(IconData icon, VoidCallback onTap) {
    return Container(
      decoration: BoxDecoration(
        color: surfaceWhite,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF000000).withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon, color: const Color(0xFF215887)),
        onPressed: onTap,
      ),
    );
  }
}
