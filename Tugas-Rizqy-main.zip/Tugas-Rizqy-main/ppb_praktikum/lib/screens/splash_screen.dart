import 'package:flutter/material.dart';
import 'home_screen.dart'; // Sesuaikan lokasi import

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color pastelPedestal = Color(0xFFB3D4E0);
    const Color surfaceWhite = Color(0xFFFFFFFF);
    const Color primaryInk = Color(0xFF215887);
    const Color textSecondary = Color(0xFF718096);
    
    final ambientShadow = BoxShadow(
      color: const Color(0xFF000000).withOpacity(0.04),
      blurRadius: 15,
      offset: const Offset(0, 8),
    );

    return Scaffold(
      backgroundColor: pastelPedestal,
      body: Stack(
        children: [
          // Floating Badges Ornaments[cite: 14]
          Positioned(
            top: 100,
            left: 20,
            child: _buildBadge(surfaceWhite, ambientShadow, Icons.eco, "100% Segar"),
          ),
          Positioned(
            top: 180,
            right: 20,
            child: _buildBadge(surfaceWhite, ambientShadow, Icons.location_on, "Panen Lokal"),
          ),
          Positioned(
            bottom: 200,
            left: 40,
            child: _buildBadge(surfaceWhite, ambientShadow, Icons.local_shipping, "Kirim Kilat"),
          ),

          // Center Content[cite: 14]
          Align(
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: surfaceWhite,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [ambientShadow],
                  ),
                  child: const Center(
                    child: Icon(Icons.shopping_basket_rounded, size: 60, color: primaryInk),
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  "Ngemart.id",
                  style: TextStyle(
                    fontFamily: 'Plus Jakarta Sans',
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                    color: primaryInk,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Belanja Segar & Cepat Setiap Hari",
                  style: TextStyle(
                    fontFamily: 'Plus Jakarta Sans',
                    fontSize: 14,
                    color: textSecondary,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: primaryInk.withOpacity(0.3)),
                  ),
                  child: const Text(
                    "Siap belanja hari ini",
                    style: TextStyle(
                      fontFamily: 'Plus Jakarta Sans',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: primaryInk,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Bottom Action Area[cite: 14]
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text("Sinkronisasi keranjang...", style: TextStyle(color: primaryInk)),
                        Text("90%", style: TextStyle(fontWeight: FontWeight.bold, color: primaryInk)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(999),
                      child: const LinearProgressIndicator(
                        value: 0.9,
                        minHeight: 6,
                        color: primaryInk,
                        backgroundColor: surfaceWhite,
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: TextButton(
                        style: TextButton.styleFrom(
                          backgroundColor: primaryInk,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                        onPressed: () {
                          // Routing ke HomeScreen[cite: 14]
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => const HomeScreen()),
                          );
                        },
                        child: const Text(
                          "Masuk ke Beranda ->",
                          style: TextStyle(color: surfaceWhite, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBadge(Color bg, BoxShadow shadow, IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        boxShadow: [shadow],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: const Color(0xFF215887)),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}