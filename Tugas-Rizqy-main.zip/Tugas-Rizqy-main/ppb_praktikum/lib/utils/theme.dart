import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Palet Warna Pastel Drift
  static const Color canvasColor = Color(0xFFF4F4EB);
  static const Color primaryInk = Color(0xFF215887);
  static const Color pastelPedestal = Color(0xFFB3D4E0);
  static const Color slateBody = Color(0xFF718096);
  static const Color surfaceWhite = Color(0xFFFFFFFF);

  // Bayangan Halus (Ambient Drop Shadow)
  static final List<BoxShadow> ambientShadow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.04),
      blurRadius: 15,
      offset: const Offset(0, 8),
    )
  ];

  // Tema Utama Material
  static ThemeData get theme {
    return ThemeData(
      scaffoldBackgroundColor: canvasColor,
      primaryColor: primaryInk,
      
      // Cara Paling Aman: Pasang font secara global di sini
      fontFamily: GoogleFonts.plusJakartaSans().fontFamily,
      
      // Gunakan TextTheme dan TextStyle bawaan Flutter murni
      textTheme: const TextTheme(
        titleMedium: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: primaryInk,
        ),
        bodyMedium: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w400,
          color: slateBody,
        ),
      ),
    );
  }
}