import 'package:dio/dio.dart';
import '../models/product_model.dart';

class ApiServiceProducts {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://dummyjson.com',
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 15),
    headers: {'Content-Type': 'application/json'},
  ));

  Future<ProductResponse> getAllProducts({int limit = 30, int skip = 0}) async {
    final res = await _dio.get('/products', queryParameters: {'limit': limit, 'skip': skip});
    return ProductResponse.fromJson(res.data);
  }

  Future<Product> getProduct(int id) async {
    final res = await _dio.get('/products/$id');
    return Product.fromJson(res.data);
  }

  Future<ProductResponse> searchProducts(String query) async {
    final res = await _dio.get('/products/search', queryParameters: {'q': query});
    return ProductResponse.fromJson(res.data);
  }

  Future<List<String>> getCategoryList() async {
    final res = await _dio.get('/products/category-list');
    return (res.data as List).map((e) => e.toString()).toList();
  }

  Future<ProductResponse> getProductsByCategory(String category) async {
    final res = await _dio.get('/products/category/$category');
    return ProductResponse.fromJson(res.data);
  }

  Future<Product> addProduct(Map<String, dynamic> data) async {
    final res = await _dio.post('/products/add', data: data);
    return Product.fromJson(res.data);
  }

  Future<Product> updateProduct(int id, Map<String, dynamic> data) async {
    final res = await _dio.put('/products/$id', data: data);
    return Product.fromJson(res.data);
  }

  Future<Product> deleteProduct(int id) async {
    final res = await _dio.delete('/products/$id');
    return Product.fromJson(res.data);
  }
}