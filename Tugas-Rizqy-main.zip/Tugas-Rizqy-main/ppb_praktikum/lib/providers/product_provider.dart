import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../services/api_services_product.dart';

class ProductProvider extends ChangeNotifier {
  final ApiServiceProducts _api = ApiServiceProducts();
  
  List<Product> _products = [];
  List<String> _categoryList = [];
  bool _loading = false;
  int _total = 0;

  List<Product> get products => _products;
  List<String> get categoryList => _categoryList;
  bool get loading => _loading;
  int get total => _total;

  Future<void> fetchProducts({int limit = 30, int skip = 0}) async {
    _loading = true;
    notifyListeners();
    try {
      final res = await _api.getAllProducts(limit: limit, skip: skip);
      _products = res.products;
      _total = res.total;
    } catch (e) {
      debugPrint(e.toString());
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> fetchCategories() async {
    try {
      _categoryList = await _api.getCategoryList();
      notifyListeners();
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> searchProducts(String query) async {
    if (query.isEmpty) return fetchProducts();
    _loading = true;
    notifyListeners();
    try {
      final res = await _api.searchProducts(query);
      _products = res.products;
    } catch (e) {
      debugPrint(e.toString());
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> filterByCategory(String category) async {
    _loading = true;
    notifyListeners();
    try {
      final res = await _api.getProductsByCategory(category);
      _products = res.products;
    } catch (e) {
      debugPrint(e.toString());
    }
    _loading = false;
    notifyListeners();
  }
}